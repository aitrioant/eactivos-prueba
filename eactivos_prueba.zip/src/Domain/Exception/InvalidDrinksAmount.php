<?php

namespace App\Domain\Exception;

class InvalidDrinksAmount extends \Exception
{

}