<?php

namespace App\Domain\Exception;

class NotEnoughMoney extends \Exception
{

}