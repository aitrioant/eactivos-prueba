<?php

namespace App\Domain\Exception;

class InvalidMoneyForDelivery extends \Exception
{

}