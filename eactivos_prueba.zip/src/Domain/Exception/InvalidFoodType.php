<?php

namespace App\Domain\Exception;

class InvalidFoodType extends \Exception
{

}