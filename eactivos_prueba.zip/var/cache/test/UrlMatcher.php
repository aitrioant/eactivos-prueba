<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/orders/register' => [[['_route' => 'register_order', '_controller' => 'App\\Controller\\OrderController::register'], null, ['POST' => 0], null, false, false, null]],
        '/orders/create-order' => [[['_route' => 'create_order', '_controller' => 'App\\Controller\\OrderController::createOrder'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
    ],
    [ // $dynamicRoutes
    ],
    null, // $checkCondition
];
