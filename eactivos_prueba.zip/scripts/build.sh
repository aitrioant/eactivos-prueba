#!/bin/sh

docker build -f scripts/docker/Dockerfile -t food-delivery-restaurant-php .
